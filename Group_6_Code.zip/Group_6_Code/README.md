# QBUS3830-Group-6-Assignment

This folder contains all files, from different functions. Running the single file named "Group6_Wrapper" is sufficient to get all results and plots.